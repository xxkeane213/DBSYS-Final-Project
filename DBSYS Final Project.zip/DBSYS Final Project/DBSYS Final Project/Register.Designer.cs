﻿namespace DBSYS_Final_Project
{
    partial class Register
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtCreateUsername = new System.Windows.Forms.TextBox();
            this.txtCreatePassword = new System.Windows.Forms.TextBox();
            this.btnConfirmRegister = new System.Windows.Forms.Button();
            this.chkShowRegPass = new System.Windows.Forms.CheckBox();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(37, 29);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(55, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Username";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(37, 57);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(53, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Password";
            // 
            // txtCreateUsername
            // 
            this.txtCreateUsername.Location = new System.Drawing.Point(98, 26);
            this.txtCreateUsername.Name = "txtCreateUsername";
            this.txtCreateUsername.Size = new System.Drawing.Size(202, 20);
            this.txtCreateUsername.TabIndex = 2;
            // 
            // txtCreatePassword
            // 
            this.txtCreatePassword.Location = new System.Drawing.Point(98, 54);
            this.txtCreatePassword.Name = "txtCreatePassword";
            this.txtCreatePassword.Size = new System.Drawing.Size(202, 20);
            this.txtCreatePassword.TabIndex = 3;
            // 
            // btnConfirmRegister
            // 
            this.btnConfirmRegister.Location = new System.Drawing.Point(98, 104);
            this.btnConfirmRegister.Name = "btnConfirmRegister";
            this.btnConfirmRegister.Size = new System.Drawing.Size(75, 23);
            this.btnConfirmRegister.TabIndex = 4;
            this.btnConfirmRegister.Text = "Confirm";
            this.btnConfirmRegister.UseVisualStyleBackColor = true;
            this.btnConfirmRegister.Click += new System.EventHandler(this.btnConfirmRegister_Click);
            // 
            // chkShowRegPass
            // 
            this.chkShowRegPass.AutoSize = true;
            this.chkShowRegPass.Location = new System.Drawing.Point(98, 81);
            this.chkShowRegPass.Name = "chkShowRegPass";
            this.chkShowRegPass.Size = new System.Drawing.Size(102, 17);
            this.chkShowRegPass.TabIndex = 5;
            this.chkShowRegPass.Text = "Show Password";
            this.chkShowRegPass.UseVisualStyleBackColor = true;
            this.chkShowRegPass.CheckedChanged += new System.EventHandler(this.chkShowRegPass_CheckedChanged);
            // 
            // Register
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(393, 191);
            this.Controls.Add(this.chkShowRegPass);
            this.Controls.Add(this.btnConfirmRegister);
            this.Controls.Add(this.txtCreatePassword);
            this.Controls.Add(this.txtCreateUsername);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Register";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Register";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtCreateUsername;
        private System.Windows.Forms.TextBox txtCreatePassword;
        private System.Windows.Forms.Button btnConfirmRegister;
        private System.Windows.Forms.CheckBox chkShowRegPass;
    }
}