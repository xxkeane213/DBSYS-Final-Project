﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DBSYS_Final_Project
{
    public partial class Register : Form
    {
        public Register()
        {
            InitializeComponent();
        }

        private void chkShowRegPass_CheckedChanged(object sender, EventArgs e)
        {
            if (chkShowRegPass.Checked)
            {
                txtCreatePassword.PasswordChar = '\0';
            }
            else
            {
                txtCreatePassword.PasswordChar = '•';
            }
        }

        private void btnConfirmRegister_Click(object sender, EventArgs e)
        {
            Register register  = new Register();
            this.Close();
            Login login = new Login();
            login.Show();
        }
    }
}
