CREATE DATABASE FinalProjectDuplicate;

USE FinalProjectDuplicate;

CREATE TABLE appointment
(
    appointment_id INT PRIMARY KEY,
    client_id INT,
    client_name VARCHAR(255),
    client_contact VARCHAR(255),
	client_email VARCHAR(255),
    schedule_date DATE,
    schedule_time TIME
);

CREATE TABLE users
(
	id INT PRIMARY KEY,
	userName VARCHAR(50),
	userPassword VARCHAR(50),
);

CREATE TABLE client
(
	client_id VARCHAR(50) PRIMARY KEY,
	client_name VARCHAR(255),
	client_contact VARCHAR(255),
	client_email VARCHAR(225)
);


-- Inserting values into the tables

-- Insert a sample row into the "users" table
INSERT INTO users(id, userName, userPassword)
VALUES( 1, 'admin', 'admin');

-- Insert a sample row into the "client" table
INSERT INTO client (client_id, client_name, client_contact, client_email)
VALUES (1, 'Kent Emphasis', '555-555-5555', 'kentemphasis@gmail.com');

-- Insert a sample row into the "appointment" table
INSERT INTO appointment (appointment_id, client_id, client_name, client_contact, client_email, schedule_date, schedule_time)
VALUES (1, 1, 'Emphasis Kent', '123-456-7890', 'kentemphasis@gmail.com', '12/20/00', '12:30:00');

SELECT 
    appointment_id AS 'Appointment ID',
    client_id AS 'Client ID',
    client_name AS 'Client Name',
    client_contact AS 'Client Contact',
	client_email AS 'Client Email',
    schedule_date AS 'Schedule Date',
    schedule_time AS 'Schedule Time'
FROM 
    appointment;

SELECT 
    client_id AS 'Client ID',
    client_name AS 'Client Name',
    client_contact AS 'Client Contact',
    client_email AS 'Client Email'
FROM client;

SELECT
	id AS 'User ID',
    userName AS 'User Name',
    userPassword AS 'User Password'
FROM users;