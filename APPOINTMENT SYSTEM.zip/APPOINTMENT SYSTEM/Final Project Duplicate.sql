CREATE DATABASE FinalProjectDuplicate;

USE FinalProjectDuplicate;

CREATE TABLE appointment
(
    appointment_id INT PRIMARY KEY,
    client_id INT,
    client_name VARCHAR(255),
    client_contact VARCHAR(255),
    schedule_date DATE
);

CREATE TABLE users
(
	id INT PRIMARY KEY,
	userName VARCHAR(50),
	userPassword VARCHAR(50),
);

CREATE TABLE client
(
	client_id VARCHAR(50) PRIMARY KEY,
	client_name VARCHAR(255),
	client_contact VARCHAR(255),
	client_email VARCHAR(225)
);


-- Inserting values into the tables

-- Insert a sample row into the "users" table
INSERT INTO users(id, userName, userPassword)
VALUES( 1, 'admin', 'admin');

-- Insert a sample row into the "appointment" table
INSERT INTO appointment (appointment_id, client_id, client_name, client_contact, schedule_date)
VALUES (1, 1, 'Emphasis Kent', '123-456-7890', '12/17/23');

SELECT 
    appointment_id AS 'Appointment ID',
    client_id AS 'Client ID',
    client_name AS 'Client Name',
    client_contact AS 'Client Contact',
    schedule_date AS 'Schedule Date'
FROM 
    appointment;

SELECT
	id AS 'User ID',
    userName AS 'User Name',
    userPassword AS 'User Password'
FROM users;