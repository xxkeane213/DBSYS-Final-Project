﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace APPOINTMENT_SYSTEM
{
    public partial class AdminDatabase : Form
    {
        int client_id;
        int appointment_id;
        string client_name;
        string client_contact;
        DateTime schedule_date;

        private SqlConnection con;
        DataTable table = new DataTable();
        SqlDataAdapter adapter = new SqlDataAdapter();


        public AdminDatabase()
        {
            con = new SqlConnection("Data Source=DESKTOP-LOU3UGG;Initial Catalog=FinalProjectDuplicate;Integrated Security=True");
            InitializeComponent();
            refresher();
        }
        private void refresher()
        {
            try
            {
                if (con.State == ConnectionState.Closed)
                {
                    con.Open();

                    // Refresh the appointment DataGridView
                    SqlCommand appointmentCmd = new SqlCommand("SELECT * FROM [appointment]", con);
                    adapter.SelectCommand = appointmentCmd;
                    DataTable appointmentTable = new DataTable();
                    adapter.Fill(appointmentTable);
                    AppointmentDataGridView.DataSource = appointmentTable;

                    // Refresh the users DataGridView
                    SqlCommand usersCmd = new SqlCommand("SELECT * FROM [users]", con);
                    adapter.SelectCommand = usersCmd;
                    DataTable usersTable = new DataTable();
                    adapter.Fill(usersTable);
                    UserDataGridView.DataSource = usersTable;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred while refreshing the data: " + ex.Message);
            }
            finally
            {
                con.Close();
            }
        }

        private void AdminDatabase_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'finalProjectDuplicateDataSet2.users' table.
            this.usersTableAdapter.Fill(this.finalProjectDuplicateDataSet2.users);
            // TODO: This line of code loads data into the 'finalProjectDuplicateDataSet.appointment' table.
            this.appointmentTableAdapter.Fill(this.finalProjectDuplicateDataSet.appointment);
            refresher();
        }

        private void BtnDelete_Click(object sender, EventArgs e)
        {
            try
            {
                DialogResult dr = MessageBox.Show("Are you sure you want to delete this?", "CONFIRM DELETION", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

                if (dr == DialogResult.Yes)
                {
                    if (!string.IsNullOrWhiteSpace(TxtSearchAppointments.Text) && int.TryParse(TxtSearchAppointments.Text, out int appointment_id))
                    {
                        string deleteQuery = "DELETE FROM appointment WHERE appointment_id = @appointment_id";

                        using (SqlConnection connection = new SqlConnection("Data Source=DESKTOP-LOU3UGG;Initial Catalog=FinalProjectDuplicate;Integrated Security=True"))
                        {
                            connection.Open();

                            using (SqlCommand cmd = new SqlCommand(deleteQuery, connection))
                            {
                                cmd.Parameters.AddWithValue("@appointment_id", appointment_id);

                                int rowsAffected = cmd.ExecuteNonQuery();

                                if (rowsAffected > 0)
                                {
                                    MessageBox.Show("Successfully deleted.");
                                }
                                else
                                {
                                    MessageBox.Show("Record not found or deletion failed.", "Info");
                                }
                            }
                        }
                    }
                    else
                    {
                        MessageBox.Show("Invalid appointment ID. Please enter a valid integer value.", "Invalid Input");
                    }
                }
                else
                {
                    MessageBox.Show("Cancelled.", "Cancelled Deletion");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error occurred while deleting the record: " + ex.Message);
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0 && e.RowIndex < AppointmentDataGridView.Rows.Count - 1) // Check if a valid row is clicked
            {
                DataGridViewRow selectedRow = AppointmentDataGridView.Rows[e.RowIndex];
            }
        }

        private void dataGridView3_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0 && e.RowIndex < UserDataGridView.Rows.Count - 1) // Check if a valid row is clicked
            {
                DataGridViewRow selectedRow = UserDataGridView.Rows[e.RowIndex];
            }
        }

        private void TxtSearch_TextChanged(object sender, EventArgs e)
        {
            try
            {
                con.Open();

                if (string.IsNullOrWhiteSpace(TxtSearchAppointments.Text))
                {
                    // If the TextBox is empty, reload the original data
                    refresher();
                }
                else
                {
                    SqlCommand cmd = new SqlCommand("SELECT * FROM appointment WHERE client_id = @Search OR client_name = @Search OR client_contact = @Search", con);
                    cmd.Parameters.AddWithValue("@Search", TxtSearchAppointments.Text);
                    SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                    DataTable dt = new DataTable();
                    adapter.Fill(dt);
                    AppointmentDataGridView.DataSource = dt;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred while searching for appointments: " + ex.Message);
                TxtSearchAppointments.Clear();
            }
            finally
            {
                con.Close();
            }
        }

        private void TxtSearchUsers_TextChanged(object sender, EventArgs e)
        {          
            try
            {
                con.Open();

                if (string.IsNullOrWhiteSpace(TxtSearchAppointments.Text))
                {
                    // If the TextBox is empty, reload the original data
                    refresher();
                }
                else
                {
                    SqlCommand cmd = new SqlCommand("SELECT * FROM users WHERE id = @Search OR userName = @Search OR userPassword = @Search", con);
                    cmd.Parameters.AddWithValue("@Search", TxtSearchUsers.Text);
                    SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                    DataTable dt = new DataTable();
                    adapter.Fill(dt);
                    UserDataGridView.DataSource = dt;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred while searching for appointments: " + ex.Message);
                TxtSearchAppointments.Clear();
            }
            finally
            {
                con.Close();
            }
        }

        private void BtnExit_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Are you sure you want to exit?", "", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (result == DialogResult.Yes)
            {
                Application.Exit();
            }
        }

        private void BtnRefresh_Click(object sender, EventArgs e)
        {
            refresher();
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void groupBox2_Enter(object sender, EventArgs e)
        {

        }
    }
}
