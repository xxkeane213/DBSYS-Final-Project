﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace APPOINTMENT_SYSTEM
{
    public partial class AdminDatabase : Form
    {
        int client_id;
        string client_name;
        string client_contact;
        string client_email;

        private SqlConnection con;

        public AdminDatabase()
        {
            con = new SqlConnection("Data Source=DESKTOP-LOU3UGG;Initial Catalog=FinalProjectDuplicate;Integrated Security=True");
            InitializeComponent();
        }

        private void AdminDatabase_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'finalProjectDuplicateDataSet2.users' table. You can move, or remove it, as needed.
            this.usersTableAdapter.Fill(this.finalProjectDuplicateDataSet2.users);
            // TODO: This line of code loads data into the 'finalProjectDuplicateDataSet1.client' table. You can move, or remove it, as needed.
            this.clientTableAdapter.Fill(this.finalProjectDuplicateDataSet1.client);
            // TODO: This line of code loads data into the 'finalProjectDuplicateDataSet.appointment' table. You can move, or remove it, as needed.
            this.appointmentTableAdapter.Fill(this.finalProjectDuplicateDataSet.appointment);

        }

        private void BtnDelete_Click(object sender, EventArgs e)
        {
            try
            {
                DialogResult dr = MessageBox.Show("Are you sure you want to delete this?", "CONFIRM DELETION", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

                if (dr == DialogResult.Yes)
                {
                    string deleteQuery = "DELETE FROM appointment WHERE client_id = @client_id AND client_name = @client_name AND client_contact = @client_contact AND client_email = @client_email";

                    using (SqlConnection connection = new SqlConnection("Data Source=DESKTOP-LOU3UGG;Initial Catalog=FinalProjectDuplicate;Integrated Security=True"))
                    {
                        connection.Open();

                        using (SqlCommand cmd = new SqlCommand(deleteQuery, connection))
                        {
                            // Assuming you have the values for these parameters, replace them with actual values.
                            cmd.Parameters.AddWithValue("@client_id", client_id);
                            cmd.Parameters.AddWithValue("@client_name", client_name);
                            cmd.Parameters.AddWithValue("@client_contact", client_contact);
                            cmd.Parameters.AddWithValue("@client_email", client_email);

                            int rowsAffected = cmd.ExecuteNonQuery();

                            if (rowsAffected > 0)
                            {
                                MessageBox.Show("Successfully deleted.");
                            }
                            else
                            {
                                MessageBox.Show("Record not found or deletion failed.", "Info");
                            }
                        }
                    }
                }
                else
                {
                    MessageBox.Show("Cancelled.", "Cancelled Deletion");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error occurred while deleting the record: " + ex.Message);
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0 && e.RowIndex < dataGridView1.Rows.Count - 1) // Check if a valid row is clicked
            {
                DataGridViewRow selectedRow = dataGridView1.Rows[e.RowIndex];
            }
        }

        private void dataGridView2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0 && e.RowIndex < dataGridView2.Rows.Count - 1) // Check if a valid row is clicked
            {
                DataGridViewRow selectedRow = dataGridView2.Rows[e.RowIndex];
            }
        }

        private void dataGridView3_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0 && e.RowIndex < dataGridView3.Rows.Count - 1) // Check if a valid row is clicked
            {
                DataGridViewRow selectedRow = dataGridView3.Rows[e.RowIndex];
            }
        }
    }
}
