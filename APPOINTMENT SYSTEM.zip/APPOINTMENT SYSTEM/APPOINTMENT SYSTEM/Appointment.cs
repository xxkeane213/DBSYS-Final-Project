﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace APPOINTMENT_SYSTEM
{
    public partial class Appointment : Form
    {
        private SqlConnection con;
     
        string client_id;
        string client_name;
        string client_contact;
        DateTime date;
        public Appointment()
        {
            con = new SqlConnection("Data Source=DESKTOP-LOU3UGG;Initial Catalog=FinalProjectDuplicate;Integrated Security=True");
            InitializeComponent();
        }

        private void BtnClear_Click(object sender, EventArgs e)
        {
            TxtContactNumber.Clear();
            TxtIdNumber.Clear();
            TxtName.Clear();
        }

        private void BtnConfirm_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Are you sure you want to confirm the Appointment?", "Confirm Appointment", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (result == DialogResult.Yes)
            {
                client_id = TxtIdNumber.Text;
                client_name = TxtName.Text;
                client_contact = TxtContactNumber.Text;

                try
                {
                    string insertQuery = "INSERT INTO appointment (appointment_id, client_id, client_name, client_contact, schedule_date) " +
                        "VALUES (@appointment_id, @client_id, @client_name, @client_contact, @schedule_date)";

                    using (SqlCommand insertCmd = new SqlCommand(insertQuery, con))
                    {
                        insertCmd.Parameters.AddWithValue("@appointment_id", client_id);
                        insertCmd.Parameters.AddWithValue("@client_id", client_id);
                        insertCmd.Parameters.AddWithValue("@client_name", client_name);
                        insertCmd.Parameters.AddWithValue("@client_contact", client_contact);
                        insertCmd.Parameters.AddWithValue("@schedule_date", SqlDbType.Date).Value = dateTimePicker.Value.Date;

                        con.Open();
                        int rowsAffected = insertCmd.ExecuteNonQuery();

                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("Appointment Booked successfully.");
                            TxtIdNumber.Clear();
                            TxtName.Clear();
                            TxtContactNumber.Clear();
                        }
                        else
                        {
                            MessageBox.Show("Failed to book the Appointment. Please try again.");
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("An error occurred while booking the Appointment: " + ex.Message);
                }
                finally
                {
                    con.Close();
                }
            }
            else
            {
                MessageBox.Show("Booking cancelled.");
                TxtIdNumber.Clear();
                TxtName.Clear();
                TxtContactNumber.Clear();
            }
        }

        private void Appointment_Load(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }
    }
}