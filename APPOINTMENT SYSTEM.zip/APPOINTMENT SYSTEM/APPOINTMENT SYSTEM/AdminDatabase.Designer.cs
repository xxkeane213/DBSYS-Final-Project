﻿namespace APPOINTMENT_SYSTEM
{
    partial class AdminDatabase
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.AppointmentDataGridView = new System.Windows.Forms.DataGridView();
            this.appointmentidDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.clientidDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.clientnameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.clientcontactDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.scheduledateDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.scheduletimeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.appointmentBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.finalProjectDuplicateDataSet = new APPOINTMENT_SYSTEM.FinalProjectDuplicateDataSet();
            this.appointmentTableAdapter = new APPOINTMENT_SYSTEM.FinalProjectDuplicateDataSetTableAdapters.appointmentTableAdapter();
            this.clientBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.finalProjectDuplicateDataSet1 = new APPOINTMENT_SYSTEM.FinalProjectDuplicateDataSet1();
            this.clientTableAdapter = new APPOINTMENT_SYSTEM.FinalProjectDuplicateDataSet1TableAdapters.clientTableAdapter();
            this.UserDataGridView = new System.Windows.Forms.DataGridView();
            this.idDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.userNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.userPasswordDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.usersBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.finalProjectDuplicateDataSet2 = new APPOINTMENT_SYSTEM.FinalProjectDuplicateDataSet2();
            this.usersTableAdapter = new APPOINTMENT_SYSTEM.FinalProjectDuplicateDataSet2TableAdapters.usersTableAdapter();
            this.BtnDelete = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.TxtSearchAppointments = new System.Windows.Forms.TextBox();
            this.TxtSearchUsers = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.AppointmentDataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.appointmentBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.finalProjectDuplicateDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.clientBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.finalProjectDuplicateDataSet1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.UserDataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.usersBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.finalProjectDuplicateDataSet2)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // AppointmentDataGridView
            // 
            this.AppointmentDataGridView.AutoGenerateColumns = false;
            this.AppointmentDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.AppointmentDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.appointmentidDataGridViewTextBoxColumn,
            this.clientidDataGridViewTextBoxColumn,
            this.clientnameDataGridViewTextBoxColumn,
            this.clientcontactDataGridViewTextBoxColumn,
            this.scheduledateDataGridViewTextBoxColumn,
            this.scheduletimeDataGridViewTextBoxColumn});
            this.AppointmentDataGridView.DataSource = this.appointmentBindingSource;
            this.AppointmentDataGridView.Location = new System.Drawing.Point(18, 75);
            this.AppointmentDataGridView.Name = "AppointmentDataGridView";
            this.AppointmentDataGridView.Size = new System.Drawing.Size(643, 150);
            this.AppointmentDataGridView.TabIndex = 0;
            this.AppointmentDataGridView.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // appointmentidDataGridViewTextBoxColumn
            // 
            this.appointmentidDataGridViewTextBoxColumn.DataPropertyName = "appointment_id";
            this.appointmentidDataGridViewTextBoxColumn.HeaderText = "appointment_id";
            this.appointmentidDataGridViewTextBoxColumn.Name = "appointmentidDataGridViewTextBoxColumn";
            // 
            // clientidDataGridViewTextBoxColumn
            // 
            this.clientidDataGridViewTextBoxColumn.DataPropertyName = "client_id";
            this.clientidDataGridViewTextBoxColumn.HeaderText = "client_id";
            this.clientidDataGridViewTextBoxColumn.Name = "clientidDataGridViewTextBoxColumn";
            // 
            // clientnameDataGridViewTextBoxColumn
            // 
            this.clientnameDataGridViewTextBoxColumn.DataPropertyName = "client_name";
            this.clientnameDataGridViewTextBoxColumn.HeaderText = "client_name";
            this.clientnameDataGridViewTextBoxColumn.Name = "clientnameDataGridViewTextBoxColumn";
            // 
            // clientcontactDataGridViewTextBoxColumn
            // 
            this.clientcontactDataGridViewTextBoxColumn.DataPropertyName = "client_contact";
            this.clientcontactDataGridViewTextBoxColumn.HeaderText = "client_contact";
            this.clientcontactDataGridViewTextBoxColumn.Name = "clientcontactDataGridViewTextBoxColumn";
            // 
            // scheduledateDataGridViewTextBoxColumn
            // 
            this.scheduledateDataGridViewTextBoxColumn.DataPropertyName = "schedule_date";
            this.scheduledateDataGridViewTextBoxColumn.HeaderText = "schedule_date";
            this.scheduledateDataGridViewTextBoxColumn.Name = "scheduledateDataGridViewTextBoxColumn";
            // 
            // scheduletimeDataGridViewTextBoxColumn
            // 
            this.scheduletimeDataGridViewTextBoxColumn.DataPropertyName = "schedule_time";
            this.scheduletimeDataGridViewTextBoxColumn.HeaderText = "schedule_time";
            this.scheduletimeDataGridViewTextBoxColumn.Name = "scheduletimeDataGridViewTextBoxColumn";
            // 
            // appointmentBindingSource
            // 
            this.appointmentBindingSource.DataMember = "appointment";
            this.appointmentBindingSource.DataSource = this.finalProjectDuplicateDataSet;
            // 
            // finalProjectDuplicateDataSet
            // 
            this.finalProjectDuplicateDataSet.DataSetName = "FinalProjectDuplicateDataSet";
            this.finalProjectDuplicateDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // appointmentTableAdapter
            // 
            this.appointmentTableAdapter.ClearBeforeFill = true;
            // 
            // clientBindingSource
            // 
            this.clientBindingSource.DataMember = "client";
            this.clientBindingSource.DataSource = this.finalProjectDuplicateDataSet1;
            // 
            // finalProjectDuplicateDataSet1
            // 
            this.finalProjectDuplicateDataSet1.DataSetName = "FinalProjectDuplicateDataSet1";
            this.finalProjectDuplicateDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // clientTableAdapter
            // 
            this.clientTableAdapter.ClearBeforeFill = true;
            // 
            // UserDataGridView
            // 
            this.UserDataGridView.AutoGenerateColumns = false;
            this.UserDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.UserDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.idDataGridViewTextBoxColumn,
            this.userNameDataGridViewTextBoxColumn,
            this.userPasswordDataGridViewTextBoxColumn});
            this.UserDataGridView.DataSource = this.usersBindingSource;
            this.UserDataGridView.Location = new System.Drawing.Point(18, 68);
            this.UserDataGridView.Name = "UserDataGridView";
            this.UserDataGridView.Size = new System.Drawing.Size(342, 150);
            this.UserDataGridView.TabIndex = 2;
            this.UserDataGridView.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView3_CellContentClick);
            // 
            // idDataGridViewTextBoxColumn
            // 
            this.idDataGridViewTextBoxColumn.DataPropertyName = "id";
            this.idDataGridViewTextBoxColumn.HeaderText = "id";
            this.idDataGridViewTextBoxColumn.Name = "idDataGridViewTextBoxColumn";
            // 
            // userNameDataGridViewTextBoxColumn
            // 
            this.userNameDataGridViewTextBoxColumn.DataPropertyName = "userName";
            this.userNameDataGridViewTextBoxColumn.HeaderText = "userName";
            this.userNameDataGridViewTextBoxColumn.Name = "userNameDataGridViewTextBoxColumn";
            // 
            // userPasswordDataGridViewTextBoxColumn
            // 
            this.userPasswordDataGridViewTextBoxColumn.DataPropertyName = "userPassword";
            this.userPasswordDataGridViewTextBoxColumn.HeaderText = "userPassword";
            this.userPasswordDataGridViewTextBoxColumn.Name = "userPasswordDataGridViewTextBoxColumn";
            // 
            // usersBindingSource
            // 
            this.usersBindingSource.DataMember = "users";
            this.usersBindingSource.DataSource = this.finalProjectDuplicateDataSet2;
            // 
            // finalProjectDuplicateDataSet2
            // 
            this.finalProjectDuplicateDataSet2.DataSetName = "FinalProjectDuplicateDataSet2";
            this.finalProjectDuplicateDataSet2.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // usersTableAdapter
            // 
            this.usersTableAdapter.ClearBeforeFill = true;
            // 
            // BtnDelete
            // 
            this.BtnDelete.Location = new System.Drawing.Point(12, 12);
            this.BtnDelete.Name = "BtnDelete";
            this.BtnDelete.Size = new System.Drawing.Size(75, 23);
            this.BtnDelete.TabIndex = 3;
            this.BtnDelete.Text = "Delete";
            this.BtnDelete.UseVisualStyleBackColor = true;
            this.BtnDelete.Click += new System.EventHandler(this.BtnDelete_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.TxtSearchUsers);
            this.groupBox1.Controls.Add(this.UserDataGridView);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(123, 305);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(677, 240);
            this.groupBox1.TabIndex = 6;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Users";
            this.groupBox1.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.TxtSearchAppointments);
            this.groupBox2.Controls.Add(this.AppointmentDataGridView);
            this.groupBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.Location = new System.Drawing.Point(123, 48);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(677, 240);
            this.groupBox2.TabIndex = 7;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Appointments";
            // 
            // TxtSearchAppointments
            // 
            this.TxtSearchAppointments.Location = new System.Drawing.Point(18, 34);
            this.TxtSearchAppointments.Name = "TxtSearchAppointments";
            this.TxtSearchAppointments.Size = new System.Drawing.Size(360, 22);
            this.TxtSearchAppointments.TabIndex = 8;
            this.TxtSearchAppointments.TextChanged += new System.EventHandler(this.TxtSearch_TextChanged);
            // 
            // TxtSearchUsers
            // 
            this.TxtSearchUsers.Location = new System.Drawing.Point(18, 32);
            this.TxtSearchUsers.Name = "TxtSearchUsers";
            this.TxtSearchUsers.Size = new System.Drawing.Size(360, 22);
            this.TxtSearchUsers.TabIndex = 3;
            this.TxtSearchUsers.TextChanged += new System.EventHandler(this.TxtSearchUsers_TextChanged);
            // 
            // AdminDatabase
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(823, 570);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.BtnDelete);
            this.Name = "AdminDatabase";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "AdminDatabase";
            this.Load += new System.EventHandler(this.AdminDatabase_Load);
            ((System.ComponentModel.ISupportInitialize)(this.AppointmentDataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.appointmentBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.finalProjectDuplicateDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.clientBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.finalProjectDuplicateDataSet1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.UserDataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.usersBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.finalProjectDuplicateDataSet2)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView AppointmentDataGridView;
        private FinalProjectDuplicateDataSet finalProjectDuplicateDataSet;
        private System.Windows.Forms.BindingSource appointmentBindingSource;
        private FinalProjectDuplicateDataSetTableAdapters.appointmentTableAdapter appointmentTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn appointmentidDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn clientidDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn clientnameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn clientcontactDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn scheduledateDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn scheduletimeDataGridViewTextBoxColumn;
        private FinalProjectDuplicateDataSet1 finalProjectDuplicateDataSet1;
        private System.Windows.Forms.BindingSource clientBindingSource;
        private FinalProjectDuplicateDataSet1TableAdapters.clientTableAdapter clientTableAdapter;
        private System.Windows.Forms.DataGridView UserDataGridView;
        private FinalProjectDuplicateDataSet2 finalProjectDuplicateDataSet2;
        private System.Windows.Forms.BindingSource usersBindingSource;
        private FinalProjectDuplicateDataSet2TableAdapters.usersTableAdapter usersTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn idDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn userNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn userPasswordDataGridViewTextBoxColumn;
        private System.Windows.Forms.Button BtnDelete;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox TxtSearchAppointments;
        private System.Windows.Forms.TextBox TxtSearchUsers;
    }
}